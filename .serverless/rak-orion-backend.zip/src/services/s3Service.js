require('dotenv').config();
// 👇 IMPORTANTE: Agregamos ListObjectsV2Command para poder listar archivos
const { S3Client, PutObjectCommand, ListObjectsV2Command } = require('@aws-sdk/client-s3');

// 1. Configuración del Cliente S3
// CORRECCIÓN: Quitamos el objeto 'credentials'. 
// El SDK detectará automáticamente si está en Local (.env) o en Lambda (IAM Role + Session Token)
const s3Client = new S3Client({
    region: process.env.AWS_REGION || 'us-east-1'
});

// 2. Mock Global para Local
global.mockS3Files = global.mockS3Files || {};

/**
 * Sube un archivo a S3 (Prod) o al Mock (Local)
 */
const uploadFile = async (fileName, fileBuffer, mimeType) => {
    const isProduction = process.env.NODE_ENV === 'production';
    const bucketName = process.env.S3_BUCKET_NAME; // Ya viene del serverless.yml

    if (isProduction) {
        // --- LÓGICA AWS REAL (NUBE) ---
        console.log(`[S3] Subiendo ${fileName} a bucket: ${bucketName}...`);
        
        const command = new PutObjectCommand({
            Bucket: bucketName,
            Key: fileName,
            Body: fileBuffer,
            ContentType: mimeType,
        });

        try {
            await s3Client.send(command);
            // Retornamos la URL pública estándar de S3
            return `https://${bucketName}.s3.amazonaws.com/${fileName}`;
        } catch (error) {
            console.error("[S3] Error crítico subiendo a AWS:", error);
            throw new Error("Fallo al subir archivo a S3: " + error.message);
        }

    } else {
        // --- LÓGICA MOCK (LOCAL) ---
        console.log(`[MOCK] Guardando ${fileName} en memoria RAM...`);
        global.mockS3Files[fileName] = fileBuffer;
        
        const port = process.env.APP_PORT || 9000;
        return `http://localhost:${port}/mock-s3/${fileName}`;
    }
};

/**
 * CORRECCIÓN: Agregamos la función faltante para listar archivos
 */
const listFiles = async () => {
    const isProduction = process.env.NODE_ENV === 'production';
    const bucketName = process.env.S3_BUCKET_NAME;

    if (isProduction) {
        try {
            // Comando para listar objetos del bucket
            const command = new ListObjectsV2Command({ Bucket: bucketName });
            const response = await s3Client.send(command);
            
            // Mapeamos la respuesta de AWS a un formato limpio
            return (response.Contents || []).map(item => ({
                key: item.Key,
                fileName: item.Key,
                url: `https://${bucketName}.s3.amazonaws.com/${item.Key}`,
                lastModified: item.LastModified,
                size: item.Size
            }));
        } catch (error) {
            console.error("[S3] Error listando archivos:", error);
            throw new Error("Error al listar archivos de S3");
        }
    } else {
        // Lógica Mock Local
        return Object.keys(global.mockS3Files || {}).map(key => ({
            key,
            fileName: key,
            url: `http://localhost:${process.env.APP_PORT || 9000}/mock-s3/${key}`,
            lastModified: new Date()
        }));
    }
};

// 👇 Asegúrate de exportar AMBAS funciones
module.exports = { uploadFile, listFiles };